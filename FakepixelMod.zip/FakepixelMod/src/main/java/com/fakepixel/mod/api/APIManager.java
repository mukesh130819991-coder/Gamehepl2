package com.fakepixel.mod.api;

import com.fakepixel.mod.FakepixelMod;
import com.fakepixel.mod.cache.PriceCache;
import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import com.google.gson.JsonParser;
import net.minecraft.client.Minecraft;
import net.minecraft.util.ChatComponentText;
import net.minecraft.util.EnumChatFormatting;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.Map;

public class APIManager {

    // Fakepixel API base — same structure as Hypixel
    private static final String BASE     = "https://api.fakepixel.me/api/v1";
    private static final String BAZAAR   = BASE + "/skyblock/bazaar";
    private static final String AUCTIONS = BASE + "/skyblock/auctions";

    private long lastFetch = 0;
    private static final long COOLDOWN_MS = 60_000; // 1 minute

    public void fetchAll() {
        new Thread(() -> {
            long now = System.currentTimeMillis();
            if (now - lastFetch < COOLDOWN_MS) return;
            lastFetch = now;

            fetchBazaar();
            fetchAH();
        }, "FakepixelMod-Fetch").start();
    }

    private void fetchBazaar() {
        try {
            String url = BAZAAR;
            if (!FakepixelMod.apiKey.isEmpty()) url += "?key=" + FakepixelMod.apiKey;

            String json = get(url);
            if (json == null) return;

            JsonObject root = new JsonParser().parse(json).getAsJsonObject();
            if (!root.has("products")) return;

            JsonObject products = root.getAsJsonObject("products");
            for (Map.Entry<String, JsonElement> entry : products.entrySet()) {
                String itemId = entry.getKey();
                JsonObject item = entry.getValue().getAsJsonObject();

                if (!item.has("quick_status")) continue;
                JsonObject qs = item.getAsJsonObject("quick_status");

                double buyPrice  = qs.has("buyPrice")  ? qs.get("buyPrice").getAsDouble()  : 0;
                double sellPrice = qs.has("sellPrice") ? qs.get("sellPrice").getAsDouble() : 0;

                if (buyPrice > 0 || sellPrice > 0) {
                    PriceCache.putBazaar(itemId, buyPrice, sellPrice);
                }
            }

            sendChat(EnumChatFormatting.GREEN + "[FP Mod] Bazaar prices loaded!");

        } catch (Exception e) {
            sendChat(EnumChatFormatting.RED + "[FP Mod] Failed to load bazaar: " + e.getMessage());
        }
    }

    private void fetchAH() {
        try {
            String url = AUCTIONS;
            if (!FakepixelMod.apiKey.isEmpty()) url += "?key=" + FakepixelMod.apiKey;

            String json = get(url);
            if (json == null) return;

            JsonObject root = new JsonParser().parse(json).getAsJsonObject();
            if (!root.has("auctions")) return;

            // Track lowest and highest BIN per item
            java.util.Map<String, Double> lowest  = new java.util.HashMap<>();
            java.util.Map<String, Double> highest = new java.util.HashMap<>();

            for (JsonElement el : root.getAsJsonArray("auctions")) {
                JsonObject auction = el.getAsJsonObject();
                if (!auction.has("bin") || !auction.get("bin").getAsBoolean()) continue;

                String name  = auction.has("item_name") ? auction.get("item_name").getAsString() : "";
                double price = auction.has("starting_bid") ? auction.get("starting_bid").getAsDouble() : 0;

                if (name.isEmpty() || price <= 0) continue;

                String key = name.toLowerCase().trim();
                lowest.merge(key, price, Math::min);
                highest.merge(key, price, Math::max);
            }

            for (String key : lowest.keySet()) {
                PriceCache.putAH(key, lowest.get(key), highest.getOrDefault(key, lowest.get(key)));
            }

            sendChat(EnumChatFormatting.GREEN + "[FP Mod] AH prices loaded!");

        } catch (Exception e) {
            sendChat(EnumChatFormatting.RED + "[FP Mod] Failed to load AH: " + e.getMessage());
        }
    }

    private String get(String urlStr) {
        try {
            HttpURLConnection conn = (HttpURLConnection) new URL(urlStr).openConnection();
            conn.setRequestMethod("GET");
            conn.setConnectTimeout(5000);
            conn.setReadTimeout(10000);
            conn.setRequestProperty("User-Agent", "FakepixelMod/1.0");

            if (conn.getResponseCode() != 200) return null;

            BufferedReader br = new BufferedReader(new InputStreamReader(conn.getInputStream()));
            StringBuilder sb = new StringBuilder();
            String line;
            while ((line = br.readLine()) != null) sb.append(line);
            br.close();
            return sb.toString();
        } catch (Exception e) {
            return null;
        }
    }

    private void sendChat(String msg) {
        Minecraft mc = Minecraft.getMinecraft();
        if (mc.thePlayer != null) {
            mc.thePlayer.addChatMessage(new ChatComponentText(msg));
        }
    }
}
