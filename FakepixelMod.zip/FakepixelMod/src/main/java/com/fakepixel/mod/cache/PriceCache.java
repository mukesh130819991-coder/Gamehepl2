package com.fakepixel.mod.cache;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class PriceCache {

    // Bazaar: itemId -> BazaarData
    private static final Map<String, BazaarData> bazaar = new HashMap<>();
    // AH: itemName -> AHData
    private static final Map<String, AHData> ah = new HashMap<>();

    // ---------- Bazaar ----------
    public static void putBazaar(String id, double buyPrice, double sellPrice) {
        bazaar.put(normalize(id), new BazaarData(buyPrice, sellPrice));
    }

    public static BazaarData getBazaar(String id) {
        return bazaar.get(normalize(id));
    }

    public static Map<String, BazaarData> getAllBazaar() {
        return bazaar;
    }

    // ---------- AH ----------
    public static void putAH(String name, double lowestBin, double highestBin) {
        ah.put(normalize(name), new AHData(lowestBin, highestBin));
    }

    public static AHData getAH(String name) {
        return ah.get(normalize(name));
    }

    // ---------- Top Flips ----------
    public static List<FlipEntry> getTopFlips(int limit) {
        List<FlipEntry> list = new ArrayList<>();
        for (Map.Entry<String, BazaarData> entry : bazaar.entrySet()) {
            BazaarData d = entry.getValue();
            double profit = d.sellPrice - d.buyPrice;
            if (profit > 0) list.add(new FlipEntry(entry.getKey(), d.buyPrice, d.sellPrice, profit));
        }
        list.sort((a, b) -> Double.compare(b.profit, a.profit));
        return list.subList(0, Math.min(limit, list.size()));
    }

    private static String normalize(String s) {
        return s.toLowerCase().replace("_", " ").replaceAll("§[0-9a-fk-or]", "").trim();
    }

    // ---------- Inner classes ----------
    public static class BazaarData {
        public final double buyPrice, sellPrice;
        public BazaarData(double b, double s) { buyPrice = b; sellPrice = s; }
    }

    public static class AHData {
        public final double lowestBin, highestBin;
        public AHData(double l, double h) { lowestBin = l; highestBin = h; }
    }

    public static class FlipEntry {
        public final String name;
        public final double buyPrice, sellPrice, profit;
        public FlipEntry(String n, double b, double s, double p) {
            name = n; buyPrice = b; sellPrice = s; profit = p;
        }
    }
}
