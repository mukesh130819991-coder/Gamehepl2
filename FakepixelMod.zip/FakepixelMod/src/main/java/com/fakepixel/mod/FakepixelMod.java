package com.fakepixel.mod;

import com.fakepixel.mod.api.APIManager;
import com.fakepixel.mod.commands.ModCommand;
import com.fakepixel.mod.events.GuiListener;
import com.fakepixel.mod.events.TooltipListener;
import com.fakepixel.mod.gui.FlipOverlayGui;
import net.minecraft.client.Minecraft;
import net.minecraftforge.client.ClientCommandHandler;
import net.minecraftforge.common.MinecraftForge;
import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.fml.common.event.FMLInitializationEvent;
import net.minecraftforge.fml.common.event.FMLPostInitializationEvent;

@Mod(modid = FakepixelMod.MODID, version = FakepixelMod.VERSION, name = FakepixelMod.NAME, clientSideOnly = true)
public class FakepixelMod {

    public static final String MODID   = "fakepixelmod";
    public static final String VERSION = "1.0.0";
    public static final String NAME    = "Fakepixel Mod";

    @Mod.Instance(MODID)
    public static FakepixelMod instance;

    public static APIManager    apiManager;
    public static FlipOverlayGui flipOverlay;
    public static String         apiKey = ""; // set via /fpmod setkey <key>

    @Mod.EventHandler
    public void init(FMLInitializationEvent e) {
        apiManager  = new APIManager();
        flipOverlay = new FlipOverlayGui();

        MinecraftForge.EVENT_BUS.register(flipOverlay);
        MinecraftForge.EVENT_BUS.register(new GuiListener());
        MinecraftForge.EVENT_BUS.register(new TooltipListener());

        ClientCommandHandler.instance.registerCommand(new ModCommand());
    }

    @Mod.EventHandler
    public void postInit(FMLPostInitializationEvent e) {
        // Fetch prices on startup
        apiManager.fetchAll();
    }
}
