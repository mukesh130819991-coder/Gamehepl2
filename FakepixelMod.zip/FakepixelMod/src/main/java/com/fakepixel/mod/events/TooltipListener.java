package com.fakepixel.mod.events;

import com.fakepixel.mod.cache.PriceCache;
import com.fakepixel.mod.utils.FormatUtil;
import net.minecraft.item.ItemStack;
import net.minecraft.nbt.NBTTagCompound;
import net.minecraftforge.event.entity.player.ItemTooltipEvent;
import net.minecraftforge.fml.common.eventhandler.SubscribeEvent;

public class TooltipListener {

    @SubscribeEvent
    public void onTooltip(ItemTooltipEvent event) {
        ItemStack stack = event.itemStack;
        if (stack == null) return;

        String itemName = getItemName(stack);
        if (itemName.isEmpty()) return;

        boolean added = false;

        // --- Bazaar prices ---
        PriceCache.BazaarData bazaar = PriceCache.getBazaar(itemName);
        if (bazaar != null) {
            if (!added) {
                event.toolTip.add(""); // spacer
                event.toolTip.add("§6§l✦ Bazaar");
                added = true;
            }
            event.toolTip.add("§7Buy Price: §a" + FormatUtil.format(bazaar.buyPrice) + " coins");
            event.toolTip.add("§7Sell Price: §c" + FormatUtil.format(bazaar.sellPrice) + " coins");
            double profit = bazaar.sellPrice - bazaar.buyPrice;
            if (profit > 0) {
                event.toolTip.add("§7Profit: §6+" + FormatUtil.format(profit));
            }
        }

        // --- AH prices ---
        PriceCache.AHData ah = PriceCache.getAH(itemName);
        if (ah != null) {
            event.toolTip.add(""); // spacer
            event.toolTip.add("§5§l✦ Auction House");
            if (ah.lowestBin > 0)  event.toolTip.add("§7Lowest BIN:  §a" + FormatUtil.format(ah.lowestBin) + " coins");
            if (ah.highestBin > 0) event.toolTip.add("§7Highest BIN: §c" + FormatUtil.format(ah.highestBin) + " coins");
        }
    }

    private String getItemName(ItemStack stack) {
        // Try display name first
        NBTTagCompound tag = stack.getTagCompound();
        if (tag != null && tag.hasKey("display")) {
            NBTTagCompound display = tag.getCompoundTag("display");
            if (display.hasKey("Name")) {
                return stripColor(display.getString("Name"));
            }
        }
        // Fall back to item registry name
        return stack.getDisplayName() != null ? stripColor(stack.getDisplayName()) : "";
    }

    private String stripColor(String s) {
        return s.replaceAll("§[0-9a-fk-or]", "").trim();
    }
}
