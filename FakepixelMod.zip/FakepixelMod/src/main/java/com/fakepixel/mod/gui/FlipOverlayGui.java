package com.fakepixel.mod.gui;

import com.fakepixel.mod.cache.PriceCache;
import com.fakepixel.mod.utils.FormatUtil;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.Gui;
import net.minecraft.client.gui.FontRenderer;
import net.minecraftforge.client.event.RenderGameOverlayEvent;
import net.minecraftforge.fml.common.eventhandler.SubscribeEvent;
import org.lwjgl.opengl.GL11;

import java.util.List;

public class FlipOverlayGui extends Gui {

    private boolean visible = false;

    private static final int X       = 4;
    private static final int Y       = 40;
    private static final int WIDTH   = 175;
    private static final int PAD     = 5;
    private static final int ROW_H   = 24;

    public void setVisible(boolean v) { this.visible = v; }

    @SubscribeEvent
    public void onRender(RenderGameOverlayEvent.Post event) {
        if (event.type != RenderGameOverlayEvent.ElementType.ALL) return;
        if (!visible) return;

        List<PriceCache.FlipEntry> flips = PriceCache.getTopFlips(8);
        if (flips.isEmpty()) return;

        Minecraft mc = Minecraft.getMinecraft();
        FontRenderer fr = mc.fontRendererObj;

        int totalH = PAD + 12 + PAD + (flips.size() * ROW_H) + PAD;

        GL11.glPushMatrix();
        GL11.glEnable(GL11.GL_BLEND);

        // Background panel
        drawRect(X, Y, X + WIDTH, Y + totalH, 0xBB000000);

        // Title bar
        drawRect(X, Y, X + WIDTH, Y + PAD + 12 + PAD, 0xCC1A1A2E);
        fr.drawStringWithShadow("§e§lFakepixel §6§lTop Flips", X + PAD, Y + PAD, 0xFFFFFF);

        int y = Y + PAD + 12 + PAD;

        for (int i = 0; i < flips.size(); i++) {
            PriceCache.FlipEntry flip = flips.get(i);

            // Alternating row background
            int rowColor = (i % 2 == 0) ? 0x22FFFFFF : 0x11FFFFFF;
            drawRect(X + 2, y, X + WIDTH - 2, y + ROW_H - 1, rowColor);

            // Item name (truncated)
            String name = truncate(fr, flip.name, WIDTH - PAD * 2);
            fr.drawStringWithShadow("§f" + name, X + PAD, y + 2, 0xFFFFFF);

            // Buy / Sell on second line
            String buyStr  = "§7B:§a" + FormatUtil.format(flip.buyPrice);
            String sellStr = "§7S:§c" + FormatUtil.format(flip.sellPrice);
            fr.drawStringWithShadow(buyStr + " " + sellStr, X + PAD, y + 12, 0xFFFFFF);

            // Profit right-aligned
            String profitStr = "§6+" + FormatUtil.format(flip.profit);
            int pw = fr.getStringWidth(profitStr);
            fr.drawStringWithShadow(profitStr, X + WIDTH - pw - PAD, y + 12, 0xFFFFFF);

            y += ROW_H;
        }

        GL11.glDisable(GL11.GL_BLEND);
        GL11.glPopMatrix();
    }

    private String truncate(FontRenderer fr, String text, int maxWidth) {
        if (fr.getStringWidth(text) <= maxWidth) return text;
        while (fr.getStringWidth(text + "…") > maxWidth && text.length() > 1) {
            text = text.substring(0, text.length() - 1);
        }
        return text + "…";
    }
}
