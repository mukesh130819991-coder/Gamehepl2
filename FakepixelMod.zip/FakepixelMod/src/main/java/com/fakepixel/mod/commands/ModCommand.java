package com.fakepixel.mod.commands;

import com.fakepixel.mod.FakepixelMod;
import net.minecraft.command.CommandBase;
import net.minecraft.command.ICommandSender;
import net.minecraft.util.ChatComponentText;
import net.minecraft.util.EnumChatFormatting;

import java.util.Arrays;
import java.util.List;

public class ModCommand extends CommandBase {

    @Override
    public String getCommandName() { return "fpmod"; }

    @Override
    public String getCommandUsage(ICommandSender sender) {
        return "/fpmod <setkey|refresh|help>";
    }

    @Override
    public List<String> getCommandAliases() {
        return Arrays.asList("fakepixelmod", "fpm");
    }

    @Override
    public void processCommand(ICommandSender sender, String[] args) {
        if (args.length == 0 || args[0].equalsIgnoreCase("help")) {
            sendMsg(sender, "§e§lFakepixel Mod Commands:");
            sendMsg(sender, "§7/fpmod setkey §f<apikey> §7- Set your Fakepixel API key");
            sendMsg(sender, "§7/fpmod refresh §7- Refresh bazaar & AH prices now");
            sendMsg(sender, "§7/fpmod help §7- Show this help");
            return;
        }

        switch (args[0].toLowerCase()) {

            case "setkey":
                if (args.length < 2) {
                    sendMsg(sender, "§cUsage: /fpmod setkey <apikey>");
                    return;
                }
                FakepixelMod.apiKey = args[1];
                sendMsg(sender, "§aAPI key set! Refreshing prices...");
                FakepixelMod.apiManager.fetchAll();
                break;

            case "refresh":
                sendMsg(sender, "§eRefreshing prices...");
                FakepixelMod.apiManager.fetchAll();
                break;

            default:
                sendMsg(sender, "§cUnknown command. Use /fpmod help");
        }
    }

    private void sendMsg(ICommandSender sender, String msg) {
        sender.addChatMessage(new ChatComponentText(msg));
    }

    @Override
    public int getRequiredPermissionLevel() { return 0; }
}
