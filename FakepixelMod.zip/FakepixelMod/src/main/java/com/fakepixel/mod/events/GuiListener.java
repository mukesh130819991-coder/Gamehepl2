package com.fakepixel.mod.events;

import com.fakepixel.mod.FakepixelMod;
import net.minecraft.client.gui.inventory.GuiChest;
import net.minecraft.inventory.ContainerChest;
import net.minecraft.inventory.IInventory;
import net.minecraftforge.client.event.GuiOpenEvent;
import net.minecraftforge.fml.common.eventhandler.SubscribeEvent;

public class GuiListener {

    @SubscribeEvent
    public void onGuiOpen(GuiOpenEvent event) {
        if (!(event.gui instanceof GuiChest)) {
            FakepixelMod.flipOverlay.setVisible(false);
            return;
        }

        GuiChest chest = (GuiChest) event.gui;
        ContainerChest container = (ContainerChest) chest.inventorySlots;
        IInventory inv = container.getLowerChestInventory();
        String title = inv.getDisplayName().getUnformattedText().toLowerCase();

        boolean isBazaar = title.contains("bazaar");

        if (isBazaar) {
            // Show flip overlay and refresh prices
            FakepixelMod.flipOverlay.setVisible(true);
            FakepixelMod.apiManager.fetchAll();
        } else {
            FakepixelMod.flipOverlay.setVisible(false);
        }
    }
}
