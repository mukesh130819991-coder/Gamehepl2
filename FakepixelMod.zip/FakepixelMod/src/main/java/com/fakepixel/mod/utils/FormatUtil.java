package com.fakepixel.mod.utils;

import java.text.DecimalFormat;

public class FormatUtil {

    private static final DecimalFormat DF = new DecimalFormat("#,##0.##");

    public static String format(double value) {
        if (value >= 1_000_000_000) return DF.format(value / 1_000_000_000) + "B";
        if (value >= 1_000_000)     return DF.format(value / 1_000_000)     + "M";
        if (value >= 1_000)         return DF.format(value / 1_000)         + "k";
        return DF.format(value);
    }
}
